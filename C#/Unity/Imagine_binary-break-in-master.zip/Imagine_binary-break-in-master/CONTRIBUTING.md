![](https://github.com/Microsoft/Imagine_binary-break-in/blob/master/Microsoft-Imagine.png)

## Contributing 

Hello and thank you for considering contributing to the Microsoft Imagine open source learn-to-code kits!

## How to help us out
Our small, but determined team appreciates your help! One of the best ways to help us (and keep it simple) is to [find and log bugs](https://github.com/Microsoft/Imagine_binary-break-in/issues): Screenshots, links to video clips are especially valuable to helping us reproduce the issue.

Spread the word to friends and family about our [learn-to-code kits](https://msdn.microsoft.com/imagine/imagine-create), have them try them out, and see what we can do to improve them.

Thanks much!




