﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameController : MonoBehaviour
{
    [SerializeField]
    private Rigidbody2D ball;
    [SerializeField]
    private GameObject charFront;
    [SerializeField]
    private GameObject charSide;

    private new Vector2 transform = new Vector2(-100f, 0f);

    private bool sw = false;

    void Update()
    {
        if (Input.GetKey(KeyCode.Space))
        {
            charSide.SetActive(true);
            charFront.SetActive(false);
        }
        if (Input.GetKeyUp(KeyCode.Space))
        {
            charSide.SetActive(false);
            charFront.SetActive(true);
        }

        if (sw) return;
        if (Input.GetKeyDown(KeyCode.Space))
        {
            ball.AddForce(transform);
            sw = true;
        }
    }
}
