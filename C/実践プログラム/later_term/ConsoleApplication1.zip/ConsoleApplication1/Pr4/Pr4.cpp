// Pr4.cpp : �R���\�[�� �A�v���P�[�V�����̃G���g�� �|�C���g���`���܂��B
//

#include "stdafx.h"

#define FIRST 0
#define SECOND 1
#define BUF_SIZE 0x20


int checksp(int c);
void compress(char *s);
int ext_atoi(char *str);
int get_num2(int *a, int *b);

int main(void)
{
#if FIRST
	char s[] = "     Nice to \n meet \t you    ,  Jack !\n     I'm      Mike \n\t\t .    ";

	printf("Before\t=\t\"%s\"\n", s);
	compress(s);

	printf("After\t=\t\"%s\"\n", s);
#endif // FIRST

#if SECOND
	int a, b, r;

	putchar('>');
	r = get_num2(&a, &b);

	printf("a = %d, b = %d, r = %d\n", a, b, r);
#endif // SECOND

	return 0;
}

int checksp(int c)
{
	return ((c == '\t') || (c == '\n') || (c == ' ')) ? 1 : 0;
}

void compress(char *s)
{
	char *p;
	p = s;

	while (checksp(*s))	s++;	/* �s���̋󔒂����� */

	/* �V������������쐬���Ă��� */
	while (*s)	/* while�����̏������L������i�K������while���Ŏ������Ȃ��Ă��ǂ��j*/
	{
		if ((checksp(*s) == 1) && (checksp(*(s + 1)) == 1))	s++;
		else if ((checksp(*s) == 1) && (checksp(*(s + 1)) == 0))
		{
			if ((*(s + 1) != ',') && (*(s + 1) != '.'))
			{
				*p = ' ';
				p++;
			}
			s++;
		}
		else
		{
			*p = *s;
			p++;
			s++;
		}
	}

	s = p;
	if (checksp(*(--s)) == 1)	*s = '\0';
	*p = '\0';
}

int ext_atoi(char * str)
{
	int num = 0;
	int sign_num = 0;

	if (*str == '+')	str++;
	else if (*str == '-')
	{
		sign_num = 1;
		str++;
	}

	while (*str != '\0')
	{
		if ((*str < 48) || (*str > 57))	return -1;
		num += *str - 48;
		num *= 10;
		str++;
	}

	num /= 10;

	if (sign_num)	num = 0 - num;

	return num;
}

int get_num2(int *a, int *b)
{
	int i, result, num[1];
	const char delimiter[] = ",";
	char *tok, buff[BUF_SIZE + 1];
	result = sizeof(num) / sizeof(int) + 1;

	fgets(buff, BUF_SIZE, stdin);
	tok = strtok(buff, delimiter);
	for (i = 0; tok != NULL; i++)
	{
		num[i] = ext_atoi(tok);
		tok = strtok(NULL, delimiter);
	}

	for (i = 0; i < (sizeof(num) / sizeof(int)); i++)
	{
		if (num[i] != -1)
		{
			//dainyuu
		}
	}
}
