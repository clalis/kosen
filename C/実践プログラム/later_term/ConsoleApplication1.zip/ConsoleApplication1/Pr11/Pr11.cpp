// Pr11.cpp : �R���\�[�� �A�v���P�[�V�����̃G���g�� �|�C���g���`���܂��B
//

#include "stdafx.h"


void init(void);	/* d��pre_vertex�������� */
void search(void);	/* ���ׂĂ̒��_�Ԃ̍ŒZ�o�H��T���i�t���C�h�@�j */
void print_path(int p, int q);	/* �o�H��\���i�t���j */

int d[MAX_SIZE][MAX_SIZE];			/* ���_�Ԃ̍ŏ��R�X�g */
int pre_vertex[MAX_SIZE][MAX_SIZE];	/* �ŒZ�o�H */

/* �f�[�^�i�אڍs��j */
int adjacent[MAX_SIZE][MAX_SIZE] =
{
	{    0,  30,IMAX,  40,IMAX,IMAX,IMAX,IMAX,IMAX,IMAX,IMAX,IMAX,IMAX },		//  0: ����
	{   30,   0,  90,  60, 140,  80,IMAX,IMAX,IMAX,IMAX,IMAX,IMAX,IMAX },		//  1: ���
	{ IMAX,  90,   0,IMAX,IMAX, 110, 330, 240,IMAX,IMAX,IMAX,IMAX,IMAX },		//  2: �Q�n
	{   40,  60,IMAX,   0, 130,IMAX,IMAX,IMAX,IMAX,IMAX,IMAX,IMAX,IMAX },		//  3: ��t
	{ IMAX, 140,IMAX, 130,   0, 100, 260,IMAX,IMAX,IMAX,IMAX,IMAX,IMAX },		//  4: ���
	{ IMAX,  80, 110,IMAX, 100,   0, 170,IMAX,IMAX,IMAX,IMAX,IMAX,IMAX },		//  5: �Ȗ�
	{ IMAX,IMAX, 330,IMAX, 260, 170,   0, 550,  80,  90,IMAX,IMAX,IMAX },		//  6: ����
	{ IMAX,IMAX, 240,IMAX,IMAX,IMAX, 550,   0, 630,IMAX,IMAX,IMAX,IMAX },		//  7: �V��
	{ IMAX,IMAX,IMAX,IMAX,IMAX,IMAX,  80, 630,   0,  60, 190,IMAX,IMAX },		//  8: �R�`
	{ IMAX,IMAX,IMAX,IMAX,IMAX,IMAX,  90,IMAX,  60,   0, 290, 180,IMAX },		//  9: �{��
	{ IMAX,IMAX,IMAX,IMAX,IMAX,IMAX,IMAX,IMAX, 190, 290,   0, 110, 300 },		// 10: �H�c
	{ IMAX,IMAX,IMAX,IMAX,IMAX,IMAX,IMAX,IMAX,IMAX, 180, 110,   0, 190 },		// 11: ���
	{ IMAX,IMAX,IMAX,IMAX,IMAX,IMAX,IMAX,IMAX,IMAX,IMAX, 300, 190,   0 }		// 12: �X
};

char *graph_data[] =	// ��L�אڍs���0~12�Ԗڂ̊e�v�f�ɑΉ�
{
	"Tokyo",
	"Saitama",
	"Gunma",
	"Chiba",
	"Ibaraki",
	"Tochigi",
	"Fukushima",
	"Niigata",
	"Yamagata",
	"Miyagi",
	"Akita",
	"Iwate",
	"Aomori"
};


int main(void)
{
	int h, begin = -1, end = -1;
	char start[10], destination[10], buff[0x100];

	/* ������ */
	init();

	while (begin == -1)
	{
		printf("Please enter ur departure point. : ");
		fgets(buff, sizeof(buff), stdin);
		sscanf(buff, "%s", &start);
		for (h = 0; h < MAX_SIZE; h++)
		{
			if (!strcmp(start, graph_data[h]))
			{
				begin = h;
				break;
			}
		}
		if (h == MAX_SIZE)
		{
			printf("It doesn't exist.\n");
			begin = -1;
		}
	}
	while (end == -1)
	{
		printf("Please enter ur arrival point. : ");
		fgets(buff, sizeof(buff), stdin);
		sscanf(buff, "%s", &destination);
		for (h = 0; h < MAX_SIZE; h++)
		{
			if (!strcmp(destination, graph_data[h]))
			{
				end = h;
				break;
			}
		}
		if (h == MAX_SIZE)
		{
			printf("It doesn't exist.\n");
			end = -1;
		}
	}

	/* �T�� */
	search();

	/* �\�� */
	print_path(end, begin);	// ���s�̈��

	return 0;
}

void init(void)
{
	int i, j;

	for (i = 0; i < MAX_SIZE; i++)
	{
		for (j = 0; j < MAX_SIZE; j++)
		{
			d[i][j] = adjacent[i][j];
			pre_vertex[i][j] = i;
		}
	}
}

void search(void)
{
	int i, j, k;

	for (i = 0; i < MAX_SIZE; i++)
	{
		for (j = 0; j < MAX_SIZE; j++)
		{
			for (k = 0; k < MAX_SIZE; k++)
			{
				if (d[j][k] > (d[j][i] + d[i][k]))
				{
					d[j][k] = (d[j][i] + d[i][k]);
					pre_vertex[j][k] = pre_vertex[i][k];
				}
			}
		}
	}
}

void print_path(int p, int q)
{
	int x = q;

	printf("-|%s|-", graph_data[x]);
	do
	{
		x = pre_vertex[p][x];
		printf("-|%s|-", graph_data[x]);
	} while (x != p);
	putchar('\n');
	printf("Cost : %d\n", d[p][q]);
}
