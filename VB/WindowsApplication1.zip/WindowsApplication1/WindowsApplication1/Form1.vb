﻿Public Class Form_Clock

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Enabled = True
        Timer1.Interval = 1000
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Label_Date.Text = DateTime.Now.ToLongDateString
        Label_Time.Text = DateTime.Now.ToLongTimeString
    End Sub

End Class
