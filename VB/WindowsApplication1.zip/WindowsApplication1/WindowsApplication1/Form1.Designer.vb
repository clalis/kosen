﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_Clock
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form_Clock))
        Me.Label_Date = New System.Windows.Forms.Label()
        Me.Label_Time = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.SuspendLayout()
        '
        'Label_Date
        '
        Me.Label_Date.AutoSize = True
        Me.Label_Date.BackColor = System.Drawing.Color.Transparent
        Me.Label_Date.Font = New System.Drawing.Font("Monotype Corsiva", 64.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label_Date.Location = New System.Drawing.Point(12, 9)
        Me.Label_Date.Name = "Label_Date"
        Me.Label_Date.Size = New System.Drawing.Size(424, 86)
        Me.Label_Date.TabIndex = 0
        Me.Label_Date.Text = "Label_Date"
        Me.Label_Date.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label_Time
        '
        Me.Label_Time.AutoSize = True
        Me.Label_Time.BackColor = System.Drawing.Color.Transparent
        Me.Label_Time.Font = New System.Drawing.Font("Monotype Corsiva", 64.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label_Time.Location = New System.Drawing.Point(694, 9)
        Me.Label_Time.Name = "Label_Time"
        Me.Label_Time.Size = New System.Drawing.Size(429, 86)
        Me.Label_Time.TabIndex = 1
        Me.Label_Time.Text = "Label_Time"
        Me.Label_Time.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Timer1
        '
        '
        'Form_Clock
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.Firing_M1A1_tank_in_Djibouti
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(3188, 1045)
        Me.Controls.Add(Me.Label_Time)
        Me.Controls.Add(Me.Label_Date)
        Me.HelpButton = True
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form_Clock"
        Me.Text = "28 - 23"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label_Date As System.Windows.Forms.Label
    Friend WithEvents Label_Time As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer

End Class
