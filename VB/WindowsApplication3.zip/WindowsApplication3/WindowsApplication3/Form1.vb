﻿Public Class Form1

    Dim sum As Integer

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        sum = 0
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        sum = 1
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        End
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Dim a As Integer

        If sum = 0 Then Exit Sub

        a = sum Mod 2
        Select Case a
            Case 0
                PictureBox1.Image = PictureBox2.Image
            Case 1
                PictureBox1.Image = PictureBox3.Image
        End Select
    End Sub
End Class
