﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label_NX = New System.Windows.Forms.Label()
        Me.Label_NY = New System.Windows.Forms.Label()
        Me.Label_OX = New System.Windows.Forms.Label()
        Me.Label_OY = New System.Windows.Forms.Label()
        Me.Button_Refresh = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'ToolTip1
        '
        Me.ToolTip1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        '
        'Button1
        '
        Me.Button1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Button1.Location = New System.Drawing.Point(12, 226)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label_NX
        '
        Me.Label_NX.AutoSize = True
        Me.Label_NX.ForeColor = System.Drawing.Color.Red
        Me.Label_NX.Location = New System.Drawing.Point(12, 25)
        Me.Label_NX.Name = "Label_NX"
        Me.Label_NX.Size = New System.Drawing.Size(20, 12)
        Me.Label_NX.TabIndex = 3
        Me.Label_NX.Text = "NX"
        '
        'Label_NY
        '
        Me.Label_NY.AutoSize = True
        Me.Label_NY.ForeColor = System.Drawing.Color.Lime
        Me.Label_NY.Location = New System.Drawing.Point(38, 25)
        Me.Label_NY.Name = "Label_NY"
        Me.Label_NY.Size = New System.Drawing.Size(20, 12)
        Me.Label_NY.TabIndex = 4
        Me.Label_NY.Text = "NY"
        '
        'Label_OX
        '
        Me.Label_OX.AutoSize = True
        Me.Label_OX.ForeColor = System.Drawing.Color.White
        Me.Label_OX.Location = New System.Drawing.Point(12, 37)
        Me.Label_OX.Name = "Label_OX"
        Me.Label_OX.Size = New System.Drawing.Size(20, 12)
        Me.Label_OX.TabIndex = 5
        Me.Label_OX.Text = "OX"
        '
        'Label_OY
        '
        Me.Label_OY.AutoSize = True
        Me.Label_OY.ForeColor = System.Drawing.Color.White
        Me.Label_OY.Location = New System.Drawing.Point(38, 37)
        Me.Label_OY.Name = "Label_OY"
        Me.Label_OY.Size = New System.Drawing.Size(20, 12)
        Me.Label_OY.TabIndex = 6
        Me.Label_OY.Text = "OY"
        '
        'Button_Refresh
        '
        Me.Button_Refresh.AutoSize = True
        Me.Button_Refresh.Dock = System.Windows.Forms.DockStyle.Top
        Me.Button_Refresh.Location = New System.Drawing.Point(0, 0)
        Me.Button_Refresh.Name = "Button_Refresh"
        Me.Button_Refresh.Size = New System.Drawing.Size(284, 22)
        Me.Button_Refresh.TabIndex = 7
        Me.Button_Refresh.Text = "Refresh"
        Me.Button_Refresh.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Black
        Me.ClientSize = New System.Drawing.Size(284, 261)
        Me.Controls.Add(Me.Button_Refresh)
        Me.Controls.Add(Me.Label_OY)
        Me.Controls.Add(Me.Label_OX)
        Me.Controls.Add(Me.Label_NY)
        Me.Controls.Add(Me.Label_NX)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Form1"
        Me.Text = "28 - 23"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label_NX As System.Windows.Forms.Label
    Friend WithEvents Label_NY As System.Windows.Forms.Label
    Friend WithEvents Label_OX As System.Windows.Forms.Label
    Friend WithEvents Label_OY As System.Windows.Forms.Label
    Friend WithEvents Button_Refresh As System.Windows.Forms.Button

End Class
