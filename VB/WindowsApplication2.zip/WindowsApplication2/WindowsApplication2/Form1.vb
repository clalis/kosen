﻿Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'ToolTip1.InitialDelay = 2000
        'ToolTip1.ReshowDelay = 1000
        'ToolTip1.AutoPopDelay = 1
        Label_NX.Refresh()
        Label_NY.Refresh()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim Grpx As Graphics = Me.CreateGraphics
        Grpx.DrawLine(Pens.Green, 10, 50, 250, 150)
    End Sub

    Private Sub ToolTip1_Popup(sender As Object, e As PopupEventArgs) Handles ToolTip1.Popup
        'ToolTip1.SetToolTip(Me, PointToClient(System.Windows.Forms.Cursor.Position).X)
        'ToolTip1.SetToolTip(Me, PointToClient(System.Windows.Forms.Cursor.Position).Y)
    End Sub

    Private Sub Form1_MouseDown(sender As Object, e As MouseEventArgs) Handles Me.MouseDown
        Static OldX As Integer, OldY As Integer
        Dim Grpx As Graphics = Me.CreateGraphics
        Dim font As New Font("MS UI Gothic", 20)
        If e.Button = Windows.Forms.MouseButtons.Left Then
            Grpx.DrawLine(Pens.Blue, OldX, OldY, e.X, e.Y)
        ElseIf e.Button = Windows.Forms.MouseButtons.Right Then
            For i = 1 To 5 Step 1
                Grpx.DrawString("FFS XD", font, Brushes.Maroon, e.X + Math.Pow(i, 2.5), e.Y + Math.Pow(i, 2.5))
            Next
        End If

        Label_OX.Text = e.X
        Label_OY.Text = e.Y
        OldX = e.X
        OldY = e.Y
    End Sub

    Private Sub Label_OX_Click(sender As Object, e As EventArgs) Handles Label_OX.Click
        While (True)
            Label_NX.Text = PointToClient(System.Windows.Forms.Cursor.Position).X
            Label_NX.Refresh()
        End While
    End Sub
    Private Sub Label_OY_Click(sender As Object, e As EventArgs) Handles Label_OY.Click
        While (True)
            Label_NY.Text = PointToClient(System.Windows.Forms.Cursor.Position).Y
            Label_NY.Refresh()
        End While
    End Sub

    Private Sub Button_Refresh_Click(sender As Object, e As EventArgs) Handles Button_Refresh.Click
        Dim Grpx As Graphics = Me.CreateGraphics
        Grpx.Clear(Color.Black)
    End Sub
End Class
